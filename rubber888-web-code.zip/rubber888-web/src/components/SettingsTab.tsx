import { Trash2, Download } from 'lucide-react';
import type { DailySalesRecord } from '../types';
import '../styles/SettingsTab.css';

interface SettingsTabProps {
  records: DailySalesRecord[];
  onDeleteRecord?: (index: number) => void;
}

export default function SettingsTab({ records }: SettingsTabProps) {
  const handleClearAllData = () => {
    if (window.confirm('คุณแน่ใจหรือว่าต้องการลบข้อมูลทั้งหมด? การกระทำนี้ไม่สามารถยกเลิกได้')) {
      localStorage.removeItem('rubber888_records');
      window.location.reload();
    }
  };

  const handleExportData = () => {
    const csv = generateCSV();
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
    element.setAttribute('download', `rubber888_export_${new Date().toISOString().split('T')[0]}.csv`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const generateCSV = () => {
    let csv = 'วันที่,ราคา (บาท/กก.),รวมน้ำหนัก (กก.),รวมจำนวนเงิน (บาท),จำนวนเข่ง\n';
    
    records.forEach((record) => {
      const date = new Date(record.date).toLocaleDateString('th-TH');
      csv += `${date},${record.price.toFixed(2)},${record.totalWeight.toFixed(2)},${record.totalAmount.toFixed(2)},${record.batches.length}\n`;
    });

    // Add summary
    const totalSales = records.reduce((sum, r) => sum + r.totalAmount, 0);
    const totalWeight = records.reduce((sum, r) => sum + r.totalWeight, 0);
    const avgPrice = records.length > 0 ? records.reduce((sum, r) => sum + r.price, 0) / records.length : 0;

    csv += '\n\nสรุป\n';
    csv += `รวมจำนวนเงิน,${totalSales.toFixed(2)}\n`;
    csv += `รวมน้ำหนัก,${totalWeight.toFixed(2)}\n`;
    csv += `ราคาเฉลี่ย,${avgPrice.toFixed(2)}\n`;

    return csv;
  };

  const handleBackupData = () => {
    const backup = {
      version: '1.0',
      exportDate: new Date().toISOString(),
      records: records,
    };
    
    const element = document.createElement('a');
    element.setAttribute('href', 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2)));
    element.setAttribute('download', `rubber888_backup_${new Date().toISOString().split('T')[0]}.json`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="settings-tab">
      <div className="settings-container">
        {/* Data Management */}
        <section className="settings-section">
          <h3>จัดการข้อมูล</h3>
          
          <div className="settings-group">
            <h4>ส่งออกข้อมูล</h4>
            <p className="settings-description">ดาวน์โหลดข้อมูลของคุณในรูปแบบ CSV หรือ JSON</p>
            <div className="settings-buttons">
              <button onClick={handleExportData} className="btn btn-secondary">
                <Download size={18} /> ส่งออก CSV
              </button>
              <button onClick={handleBackupData} className="btn btn-secondary">
                <Download size={18} /> ส่งออก Backup (JSON)
              </button>
            </div>
          </div>

          <div className="settings-group">
            <h4>ข้อมูลทั้งหมด</h4>
            <p className="settings-description">จำนวนการบันทึก: <strong>{records.length}</strong> รายการ</p>
            {records.length > 0 && (
              <div className="data-stats">
                <p>รวมน้ำหนัก: <strong>{records.reduce((sum, r) => sum + r.totalWeight, 0).toFixed(2)} กก.</strong></p>
                <p>รวมจำนวนเงิน: <strong>{records.reduce((sum, r) => sum + r.totalAmount, 0).toFixed(2)} บาท</strong></p>
              </div>
            )}
          </div>
        </section>

        {/* Danger Zone */}
        <section className="settings-section danger-zone">
          <h3>⚠️ เขตอันตราย</h3>
          
          <div className="settings-group">
            <h4>ลบข้อมูลทั้งหมด</h4>
            <p className="settings-description">การกระทำนี้จะลบข้อมูลทั้งหมดและไม่สามารถยกเลิกได้</p>
            <button onClick={handleClearAllData} className="btn btn-danger">
              <Trash2 size={18} /> ลบข้อมูลทั้งหมด
            </button>
          </div>
        </section>

        {/* Information */}
        <section className="settings-section">
          <h3>ข้อมูล</h3>
          <div className="info-box">
            <p><strong>Rubber888 Web App</strong></p>
            <p>เวอร์ชัน: 1.0.0</p>
            <p>ข้อมูลของคุณถูกบันทึกไว้ในเบราว์เซอร์ของคุณ (Local Storage)</p>
            <p>ไม่มีการส่งข้อมูลไปยังเซิร์ฟเวอร์ใด ๆ</p>
          </div>
        </section>
      </div>
    </div>
  );
}
