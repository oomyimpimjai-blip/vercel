import { useState, useEffect } from 'react';
import { BarChart3, Settings, TrendingUp } from 'lucide-react';
import './App.css';
import RecordingTab from './components/RecordingTab';
import StatisticsTab from './components/StatisticsTab';
import SettingsTab from './components/SettingsTab';
import type { DailySalesRecord } from './types';

type TabType = 'recording' | 'statistics' | 'settings';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('recording');
  const [records, setRecords] = useState<DailySalesRecord[]>([]);
  const [currentTime, setCurrentTime] = useState<string>('');

  // Update time display
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString('th-TH', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const dateString = now.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      setCurrentTime(`${dateString} ${timeString}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Load records from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('rubber888_records');
    if (saved) {
      try {
        setRecords(JSON.parse(saved));
      } catch (error) {
        console.error('Error loading records:', error);
      }
    }
  }, []);

  // Save records to localStorage
  useEffect(() => {
    localStorage.setItem('rubber888_records', JSON.stringify(records));
  }, [records]);

  const handleAddRecord = (record: DailySalesRecord) => {
    setRecords([...records, record]);
  };

  const handleDeleteRecord = (index: number) => {
    setRecords(records.filter((_, i) => i !== index));
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <div className="header-left">
            <h1 className="app-title">Rubber888</h1>
            <p className="header-time">{currentTime}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="app-main">
        {activeTab === 'recording' && (
          <RecordingTab onAddRecord={handleAddRecord} />
        )}
        {activeTab === 'statistics' && (
          <StatisticsTab records={records} />
        )}
        {activeTab === 'settings' && (
          <SettingsTab records={records} onDeleteRecord={handleDeleteRecord} />
        )}
      </main>

      {/* Tab Navigation */}
      <nav className="app-nav">
        <button
          className={`nav-button ${activeTab === 'recording' ? 'active' : ''}`}
          onClick={() => setActiveTab('recording')}
          title="บันทึก"
        >
          <TrendingUp size={24} />
          <span>บันทึก</span>
        </button>
        <button
          className={`nav-button ${activeTab === 'statistics' ? 'active' : ''}`}
          onClick={() => setActiveTab('statistics')}
          title="สถิติ"
        >
          <BarChart3 size={24} />
          <span>สถิติ</span>
        </button>
        <button
          className={`nav-button ${activeTab === 'settings' ? 'active' : ''}`}
          onClick={() => setActiveTab('settings')}
          title="ตั้งค่า"
        >
          <Settings size={24} />
          <span>ตั้งค่า</span>
        </button>
      </nav>
    </div>
  );
}

export default App;
