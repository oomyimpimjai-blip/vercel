export interface RubberBatch {
  id: string;
  weight: number; // น้ำหนักเป็นกิโลกรัม
}

export interface DailySalesRecord {
  id: string;
  date: string; // ISO date string
  price: number; // ราคาต่อกิโลกรัม (บาท)
  batches: RubberBatch[];
  totalWeight: number; // รวมน้ำหนัก
  totalAmount: number; // รวมจำนวนเงิน
  notes?: string;
}

export interface SalesStatistics {
  totalRecords: number;
  totalWeight: number;
  totalAmount: number;
  averagePrice: number;
  highestPrice: number;
  lowestPrice: number;
  dateRange: {
    start: string;
    end: string;
  };
}
