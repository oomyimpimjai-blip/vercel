import { useState } from 'react';
import { Plus, Minus, Save, Download } from 'lucide-react';
import type { DailySalesRecord, RubberBatch } from '../types';
import '../styles/RecordingTab.css';

interface RecordingTabProps {
  onAddRecord: (record: DailySalesRecord) => void;
}

export default function RecordingTab({ onAddRecord }: RecordingTabProps) {
  const [price, setPrice] = useState<number>(0);
  const [batches, setBatches] = useState<RubberBatch[]>([
    { id: '1', weight: 0 },
  ]);

  const totalWeight = batches.reduce((sum, batch) => sum + batch.weight, 0);
  const totalAmount = totalWeight * price;

  const handleAddBatch = () => {
    const newId = String(batches.length + 1);
    setBatches([...batches, { id: newId, weight: 0 }]);
  };

  const handleRemoveBatch = (id: string) => {
    if (batches.length > 1) {
      setBatches(batches.filter((batch) => batch.id !== id));
    }
  };

  const handleUpdateBatchWeight = (id: string, weight: number) => {
    setBatches(
      batches.map((batch) =>
        batch.id === id ? { ...batch, weight } : batch
      )
    );
  };

  const handleSaveRecord = () => {
    if (price <= 0 || totalWeight <= 0) {
      alert('กรุณากรอกราคาและน้ำหนักให้ครบถ้วน');
      return;
    }

    const record: DailySalesRecord = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      price,
      batches,
      totalWeight,
      totalAmount,
    };

    onAddRecord(record);

    // Reset form
    setPrice(0);
    setBatches([{ id: '1', weight: 0 }]);
    alert('บันทึกข้อมูลสำเร็จ');
  };

  const handleDownloadExcel = () => {
    const csv = `วันที่,ราคา (บาท/กก.),รวมน้ำหนัก (กก.),รวมจำนวนเงิน (บาท)\n${new Date().toLocaleDateString('th-TH')},${price.toFixed(2)},${totalWeight.toFixed(2)},${totalAmount.toFixed(2)}`;
    
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
    element.setAttribute('download', `rubber888_${new Date().toISOString().split('T')[0]}.csv`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="recording-tab">
      <div className="recording-container">
        {/* Price Section */}
        <div className="price-section">
          <label htmlFor="price">ราคายางพาราวันนี้</label>
          <div className="price-input-group">
            <input
              id="price"
              type="number"
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              placeholder="0"
              min="0"
              step="0.01"
            />
            <span className="price-unit">บาท/กก.</span>
          </div>
        </div>

        {/* Batches Section */}
        <div className="batches-section">
          <div className="batches-header">
            <h3>บันทึกน้ำหนักยางพาราแต่ละเข่ง</h3>
            <span className="batch-count">จำนวน: {batches.length}</span>
          </div>

          <div className="batches-list">
            {batches.map((batch, index) => (
              <div key={batch.id} className="batch-item">
                <span className="batch-number">เข่ง {index + 1}</span>
                <input
                  type="number"
                  value={batch.weight}
                  onChange={(e) =>
                    handleUpdateBatchWeight(batch.id, Number(e.target.value))
                  }
                  placeholder="0"
                  min="0"
                  step="0.1"
                  className="batch-weight-input"
                />
                <span className="batch-unit">กก.</span>
                {batches.length > 1 && (
                  <button
                    onClick={() => handleRemoveBatch(batch.id)}
                    className="batch-remove-btn"
                    title="ลบเข่ง"
                  >
                    <Minus size={18} />
                  </button>
                )}
              </div>
            ))}
          </div>

          <button
            onClick={handleAddBatch}
            className="add-batch-btn"
          >
            <Plus size={20} /> เพิ่มเข่ง
          </button>
        </div>

        {/* Summary Section */}
        <div className="summary-section">
          <h3>สรุป</h3>
          <div className="summary-grid">
            <div className="summary-item">
              <span className="summary-label">รวมน้ำหนัก:</span>
              <span className="summary-value">{totalWeight.toFixed(2)} กก.</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">ราคา:</span>
              <span className="summary-value">{price.toFixed(2)} บาท/กก.</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">รวมจำนวนเงิน:</span>
              <span className="summary-value">{totalAmount.toFixed(2)} บาท</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="action-buttons">
          <button
            onClick={handleSaveRecord}
            className="btn btn-primary"
          >
            <Save size={20} /> บันทึกข้อมูล
          </button>
          <button
            onClick={handleDownloadExcel}
            className="btn btn-secondary"
          >
            <Download size={20} /> ดาวน์โหลด Excel
          </button>
        </div>
      </div>
    </div>
  );
}
