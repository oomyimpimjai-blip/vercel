import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { DailySalesRecord } from '../types';
import '../styles/StatisticsTab.css';

interface StatisticsTabProps {
  records: DailySalesRecord[];
}

export default function StatisticsTab({ records }: StatisticsTabProps) {
  const calculateStats = () => {
    if (records.length === 0) {
      return {
        totalRecords: 0,
        totalWeight: 0,
        totalAmount: 0,
        averagePrice: 0,
        highestPrice: 0,
        lowestPrice: 0,
      };
    }

    const totalWeight = records.reduce((sum, r) => sum + r.totalWeight, 0);
    const totalAmount = records.reduce((sum, r) => sum + r.totalAmount, 0);
    const prices = records.map(r => r.price);
    const averagePrice = prices.reduce((a, b) => a + b, 0) / prices.length;

    return {
      totalRecords: records.length,
      totalWeight: totalWeight.toFixed(2),
      totalAmount: totalAmount.toFixed(2),
      averagePrice: averagePrice.toFixed(2),
      highestPrice: Math.max(...prices).toFixed(2),
      lowestPrice: Math.min(...prices).toFixed(2),
    };
  };

  const chartData = records.map((record) => ({
    date: new Date(record.date).toLocaleDateString('th-TH'),
    price: record.price,
    weight: record.totalWeight,
    amount: record.totalAmount,
  }));

  const stats = calculateStats();

  return (
    <div className="statistics-tab">
      <div className="statistics-container">
        {/* Summary Cards */}
        <div className="stats-grid">
          <div className="stat-card">
            <h4>จำนวนการบันทึก</h4>
            <p className="stat-value">{stats.totalRecords}</p>
          </div>
          <div className="stat-card">
            <h4>รวมน้ำหนัก</h4>
            <p className="stat-value">{stats.totalWeight} กก.</p>
          </div>
          <div className="stat-card">
            <h4>รวมจำนวนเงิน</h4>
            <p className="stat-value">{stats.totalAmount} บาท</p>
          </div>
          <div className="stat-card">
            <h4>ราคาเฉลี่ย</h4>
            <p className="stat-value">{stats.averagePrice} บาท/กก.</p>
          </div>
          <div className="stat-card">
            <h4>ราคาสูงสุด</h4>
            <p className="stat-value">{stats.highestPrice} บาท/กก.</p>
          </div>
          <div className="stat-card">
            <h4>ราคาต่ำสุด</h4>
            <p className="stat-value">{stats.lowestPrice} บาท/กก.</p>
          </div>
        </div>

        {/* Charts */}
        {records.length > 0 && (
          <>
            {/* Price Chart */}
            <div className="chart-section">
              <h3>แนวโน้มราคา</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="price"
                    stroke="#8B4513"
                    name="ราคา (บาท/กก.)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Weight & Amount Chart */}
            <div className="chart-section">
              <h3>ปริมาณและจำนวนเงิน</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="weight" fill="#D2691E" name="น้ำหนัก (กก.)" />
                  <Bar dataKey="amount" fill="#228B22" name="จำนวนเงิน (บาท)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}

        {/* Records Table */}
        {records.length > 0 && (
          <div className="records-section">
            <h3>ประวัติการบันทึก</h3>
            <div className="records-table">
              <table>
                <thead>
                  <tr>
                    <th>วันที่</th>
                    <th>ราคา (บาท/กก.)</th>
                    <th>รวมน้ำหนัก (กก.)</th>
                    <th>รวมจำนวนเงิน (บาท)</th>
                    <th>จำนวนเข่ง</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((record) => (
                    <tr key={record.id}>
                      <td>{new Date(record.date).toLocaleDateString('th-TH')}</td>
                      <td>{record.price.toFixed(2)}</td>
                      <td>{record.totalWeight.toFixed(2)}</td>
                      <td>{record.totalAmount.toFixed(2)}</td>
                      <td>{record.batches.length}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {records.length === 0 && (
          <div className="empty-state">
            <p>ยังไม่มีข้อมูลการบันทึก</p>
            <p className="empty-hint">กรุณาไปที่หน้า "บันทึก" เพื่อเพิ่มข้อมูล</p>
          </div>
        )}
      </div>
    </div>
  );
}
